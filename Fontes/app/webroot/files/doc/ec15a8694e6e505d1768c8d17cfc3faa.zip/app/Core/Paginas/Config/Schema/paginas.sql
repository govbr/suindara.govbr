-- INSERT'S

INSERT INTO `status` VALUES(3, 'Ativa');
INSERT INTO `status` VALUES(4, 'Inativa');
