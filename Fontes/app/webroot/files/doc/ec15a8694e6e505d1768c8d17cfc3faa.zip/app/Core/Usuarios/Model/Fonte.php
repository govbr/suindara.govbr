<?php 

App::uses('UsuariosAppModel', 'Usuarios.Model');

class Fonte extends UsuariosAppModel {

	public $name = 'Fonte';

	public $displayField = 'nome';
}