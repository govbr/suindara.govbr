<?php 

App::uses('UsuariosAppModel', 'Usuarios.Model');

class Contraste extends UsuariosAppModel {

	public $name = 'Contraste';

	public $displayField = 'nome';
}