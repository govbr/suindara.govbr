<?php
class InstallAppController extends AppController
{
    
}