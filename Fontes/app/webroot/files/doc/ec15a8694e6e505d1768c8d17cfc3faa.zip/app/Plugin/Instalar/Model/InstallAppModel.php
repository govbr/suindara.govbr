<?php
App::uses('AppModel', 'Model');

class InstallAppModel extends AppModel {
    
}