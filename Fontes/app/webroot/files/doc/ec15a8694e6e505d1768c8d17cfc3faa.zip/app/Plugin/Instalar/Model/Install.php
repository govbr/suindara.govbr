<?php
class Install extends InstallAppModel
{
    public $useTable = false;
}